# NSU LIBRARY

A simple library management system build with JAVA and MYSQL database

![](https://s15.postimg.org/qcqofsla3/image.png)
![](https://i.imgsafe.org/1e925c2860.png)
![](https://i.imgsafe.org/1e926cdd07.png)
![](https://i.imgsafe.org/1e926adf55.png)
![](https://i.imgsafe.org/1e928b2c3c.png)
![](https://i.imgsafe.org/1eb8323993.png)
![](https://i.imgsafe.org/1ebbbc38b0.png)
![](http://image.prntscr.com/image/3cafc8a589b54f3cb068671f992cef59.png)
![](http://image.prntscr.com/image/d41c33ca2dac4a35a55c27efd1167e12.png)
![](http://image.prntscr.com/image/8fd0aa0a1d644af7b33ab0ed3f8784f7.png)