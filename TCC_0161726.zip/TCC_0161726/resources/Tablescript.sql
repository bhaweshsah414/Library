CREATE TABLE Patient(patient_id NUMBER PRIMARY KEY,patient_name VARCHAR2(20),phone VARCHAR2(10), age NUMBER,description VARCHAR2(20));
CREATE SEQUENCE patient_Id_sequence
START WITH 1000;