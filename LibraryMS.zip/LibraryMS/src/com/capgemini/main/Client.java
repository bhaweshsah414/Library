package com.capgemini.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.bean.LibBean;
import com.capgemini.dao.LibDao;
import com.capgemini.dao.LibDaoImpl;
import com.capgemini.exception.LibException;
import com.capgemini.service.LibService;
import com.capgemini.service.LibServiceImpl;

public class Client {
	public static void main(String[] args) throws LibException, SQLException{
		
		LibServiceImpl ls = new LibServiceImpl();
		Scanner sc = new Scanner(System.in);
		LibDao daoRef = new LibDaoImpl();
		LibDaoImpl Dao = new LibDaoImpl();
		
		LibBean en = new LibBean();
		do
		{
		System.out.println("Library Management System");
		System.out.println(" ");
		System.out.println("Choose an operation");
		System.out.println("1. Enter User Information");
		System.out.println("2. Request book");
		System.out.println("3. Reissue book");
		System.out.println("4. Update book");
		System.out.println("5. Delete book");
		System.out.println("6. Exit");

			
int choice=sc.nextInt();
		
		switch(choice){
		
		
		case 1: 
			
			
			
			System.out.println("Enter User Name: ");
			en.setUser_name(sc.next());

			
			try{
				if(ls.isValidStudent(en)){
					
					daoRef.addUser(en);
					//Dao.getCallid();
					System.out.println("Thank You "+en.getUser_name());
					
				}
				
			}catch(LibException e){
				e.printStackTrace();
				System.out.println("Please try Again");
			}
			
			break;
			
		case 2:
			
			System.out.println("Enter User id: ");
			en.setUser_id(sc.next());
			
			System.out.println("Enter book id: ");
			en.setBook_id(sc.next());

			
			try{
				if(ls.isValidStudent(en)){
					
					//daoRef.addUser(en);
					//Dao.getCallid();
					System.out.println("Entered book id is available for the user id "+en.getUser_id());
					
				}
				
			}catch(LibException e){
				e.printStackTrace();
				System.out.println("Please try Again");
			}
			
			break;
			
	case 3:
				
			System.out.println("Enter book id: ");
			en.setBook_id(sc.next());

			
			try{
				if(ls.isValidStudent(en)){
					
					//daoRef.addUser(en);
					//Dao.getCallid();
					System.out.println("Entered book is reissued for "+en.getUser_id());
					
				}
				
			}catch(LibException e){
				e.printStackTrace();
				System.out.println("Please try Again");
			}
			
			break;
			
			
	case 4:
		
		System.out.println("Enter your id: ");
		en.setUser_id(sc.next());
	
		
		System.out.println("Enter book id: ");
		en.setBook_id(sc.next());


	
		try{
			if(ls.isValidUser(en)){
				
				//daoRef.addUser(en);
				//Dao.getCallid();
				System.out.println("Entered book id is deleted for "+en.getUser_id());
				
			}
			
		}
		
			catch(LibException e){
			e.printStackTrace();
			System.out.println("Please try Again");
		}
		
		break;
			
case 5:
		
		System.out.println("Enter your id: ");
		en.setUser_id(sc.next());
		
		
		System.out.println("Enter book id: ");
		en.setBook_id(sc.next());

	
		try{
			if(ls.isValidUser(en)){
				
				//daoRef.addUser(en);
				//Dao.getCallid();
				System.out.println("Entered book id is updated for "+en.getUser_id());
				
			}
			
		}
		
			catch(LibException e){
			e.printStackTrace();
			System.out.println("Please try Again");
		}
		
		break;
			
		case 6:System.out.println("Thank You..");
		
        System.exit(0);
        
        break;
        
		default: System.out.println("Invalid Choice..Try Again..!!");
        
			
		
		}
		
		}while(true);
		
		
		
		

	}

}


