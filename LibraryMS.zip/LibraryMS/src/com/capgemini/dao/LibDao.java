package com.capgemini.dao;

import com.capgemini.bean.LibBean;
import com.capgemini.exception.LibException;

public interface LibDao {
	public int addUser(LibBean libbean) throws LibException;

	LibBean addUser(int user_id) throws LibException;
}
