package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import com.capgemini.bean.LibBean;
import com.capgemini.exception.LibException;
import com.capgemini.util.DbConnection;
import com.capgemini.util.Log4jHtmlLayout;



public class LibDaoImpl implements LibDao{
	
 Logger log = Logger.getAnonymousLogger();
	
	private Connection dbConnection;

	{
		try {
			dbConnection = DbConnection.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	

   
   
	
	

	//implemented Methods
	
	@Override
	public int addUser(LibBean libbean) throws LibException {
		
		String insertQuery = "insert into User values(?,?)";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			
			
			insertStatement.setString(2, libbean.getUser_name());
			
			
			
			int rows = insertStatement.executeUpdate();
			
			if(rows>0){
				System.out.println("New Entry Added..");
				log.info("New Entry is Added");
				return 1;
			}
			else 
				return 0;
				
		} catch (SQLException e) {
			
			e.printStackTrace();
//			Logger.error(e.getMessage());
			return 0;
		}
		
		
	}

	
	
	




	@Override
	public LibBean addUser(int user_id) throws LibException {
		
		String selectQuery = "select * from Users where user_name = ?";
		
		try{
		
		PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
		
		selectStatement.setInt(1, user_id);
		
		ResultSet result = selectStatement.executeQuery();
		
		while (result.next()) {
			
			String user_id1 = result.getString(1);
			
			String user_name = result.getString(2);
			
			
			LibBean libbean = new LibBean();
			//libbean.setUser_id(user_id);
			libbean.setUser_name(user_name);
		
			return libbean;
			
		}
		
		} catch(SQLException e){
			
			e.printStackTrace();
			
			throw new LibException("User not found",e);
		}
		
		return null;
	}
	
	
	
}


